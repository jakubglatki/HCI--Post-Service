﻿using System.Windows;

namespace HCI__Post_Service
{
    /// <summary>
    /// Interaction logic for deleteMessage.xaml
    /// </summary>
    public partial class SendingMessageWindow : Window
    {
        public SendingMessageWindow()
        {
            InitializeComponent();
        }
    }
}
